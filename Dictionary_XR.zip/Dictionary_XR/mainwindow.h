#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSystemTrayIcon>
#include <QMouseEvent>
#include <QGraphicsDropShadowEffect>
#include <qpainter.h>
#include <QBitmap>
#include <QTimer>
#include <QFile>
#include <QCompleter>
#include <qmath.h>
#include <qmessagebox.h>
#include <stack>

#include<QCryptographicHash>//md5加密的库
#include<QtNetwork>
#include<QJsonObject>
#include<QJsonDocument>
#include<QDesktopServices>
#include<QAction>

#include "form.h"
#include "ui_form.h"

using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::MainWindow *ui;
    QPoint last;

    struct Node{
        QString english,chinese;
        Node *left,*right;
    };

    struct AVLNode
    {
        QString english,chinese;    //data
        int bf = 0;
        AVLNode* left;
        AVLNode* right;
    };

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QSystemTrayIcon *trayIcon;

    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent *e);
    bool eventFilter(QObject *obj, QEvent *event);

    //二叉树
    Node *node;
    //AVL树
    AVLNode *avlnode;

    //登录窗口
    Form *form;

    //单词
    QString word;
    //文段
    QString text;

    //翻译类型
    QString from = "en";
    QString to = "zh";

    //读取的文件
    QString dictionary[110000];

    QString dictionary_list[2000];

    int tag = 0;
    int tag1 =0;

    QNetworkAccessManager * m_Manager;

    //读取文件
    void ReadFile();
    //下拉框匹配
    void MatchCompleter();
    //样式表
    void StyleSheet();


    //顺序查找
    void shunXu();
    //bst
    void insert(Node *&root, QString &str);
    void search(Node *root, QString str,QStringList &sl);
    //avl
    bool avlInsert(AVLNode*& root, QString &str);
    void RotateR(AVLNode *&root);
    void RotateL(AVLNode *&root);
    void RotateLR(AVLNode *&root);
    void RotateRL(AVLNode *&root);
    void avlSearch(AVLNode *root, QString str,QStringList &sl);


signals:
    void clicked();

public slots:
    void on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason);
    void lineEdit_clear();

    //解码返回值
    int replyFinished(QNetworkReply *reply);
    //发送请求
    int function_data();


};
#endif // MAINWINDOW_H
