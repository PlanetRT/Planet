#include "mainwindow.h"
#include "ui_mainwindow.h"



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //读取文件
    ReadFile();

    //下拉框匹配
    void MatchCompleter();

    //构建二叉搜索树 二分法
    /*由于文件中的单词是按顺序排列的，在采用二叉搜索树按顺序依次插入时，
     * 会导致二叉树极度不平衡，当数据量达到一定数量时可能导致崩溃。
     * 为避免该情况发生，此处采用“二分”的思想进行插入。
     * 即第一次将整个单词表二分并将中间的单词插入，第二次将一分为二的两个单词表分别二分并将中间的单词插入，以此类推。
     * 但在实际情况中，大概插入2^15个数后会导致程序崩溃，故将插入数量控制在该范围内。
     * 如果实际需要插入的单词数大于该范围，则可以在完成第一次插入后，再整体将单词表做插入（当某个单词已经插入时，忽略）。
     * 此方法仅供参考，不是最优解。
     * 对于本题二叉搜索树的插入，还可采用的方法有：26叉树（我有同学用这个做出来了，但个人感觉内存浪费较多），将文件中的单词表打乱顺序之后再插入等。*/
    node = NULL;

    for(int i=0;i<15;i++){
        int n = 0;
        for(int j=1;j<pow(2,i+1)&&n<103976;j+=2){
            n=j*51987/pow(2,i);
            insert(node,dictionary[n]);
        }
        qDebug()<<i;
    }

    for(int i=0;i<103976;i++){
        insert(node,dictionary[i]);
    }

    //构建AVL树
    avlnode = NULL;

    for(int i=0;i<103976;i++){
        avlInsert(avlnode,dictionary[i]);
    }

    //单词查询


    //安装事件过滤器
    ui->lineEdit->installEventFilter(this);

    //去掉窗口标题栏
    this->setWindowFlags(Qt::FramelessWindowHint);

    //设置窗口背景颜色
    this->setStyleSheet("background-color:white;");

    //半角
    ui->frame->setStyleSheet("border-radius:5px;");

    QPixmap pixmap = QString(":/new/prefix1/cidian.png");

    //logo
    pixmap.scaled(ui->label_2->size(), Qt::KeepAspectRatio);
    ui->label_2->setScaledContents(true);
    ui->label_2->setPixmap(pixmap);

    //背景
    ui->widget_2->setStyleSheet("background-color:rgb(235,235,235)");

    ui->lineEdit->setStyleSheet("background-color:rgb(235,235,235)");
    ui->lineEdit->setPlaceholderText("请输入单词...");
    ui->textEdit->setPlaceholderText("请输入要翻译的文字");

    ui->stackedWidget->setStyleSheet("background-color:white;");

    ui->textEdit->setStyleSheet("background-color:rgb(245,245,245)");
    ui->textEdit_2->setStyleSheet("background-color:rgb(245,245,245)");
    ui->textEdit_2->setReadOnly(true);

    ui->label_4->setStyleSheet("color:rgba(90,90,90);");
    ui->label_3->setStyleSheet("color:rgba(90,90,90);");

    ui->line->setStyleSheet("background-color:rgb(235,235,235)");
    ui->line_2->setStyleSheet("background-color:rgb(235,235,235)");
    ui->line_3->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_4->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_5->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_6->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_7->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_8->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_9->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_10->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_11->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_12->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_13->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_14->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_15->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_16->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_17->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_18->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_19->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_20->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_21->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_22->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_23->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_24->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_25->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_26->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_27->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_28->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_29->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_30->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_31->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_32->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_33->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_34->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_35->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_36->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_37->setStyleSheet("background-color:rgb(200,200,200)");
    ui->line_38->setStyleSheet("background-color:rgb(200,200,200)");


    //按钮样式表
    ui->pushButton->setStyleSheet("QPushButton{"
                                    "color:rgba(211,211,211);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "color:rgba(0,0,0);"
                                    "}"
                                    );

    ui->pushButton_2->setStyleSheet("QPushButton{"
                                    "color:rgba(211,211,211);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "color:rgba(0,0,0);"
                                    "}"
                                    );

    ui->pushButton_3->setStyleSheet("QPushButton{"
                                    "color:rgba(211,211,211);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "color:rgba(0,0,0);"
                                    "}"
                                    );
    ui->pushButton_4->setStyleSheet("QPushButton{"
                                    "color:rgba(211,211,211);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "color:rgba(0,0,0);"
                                    "}"
                                    );

    ui->pushButton_5->setStyleSheet("QPushButton{"
                                    "color:rgba(211,211,211);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "color:rgba(0,0,0);"
                                    "}"
                                    );
    ui->pushButton_6->setStyleSheet("QPushButton{"
                                    "background-color:rgb(255,69,0);"
                                    "border-style:outset;"
                                    "border-radius:5px;"
                                    "color:rgba(255,255,255);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "background-color:rgb(255,69,0,200);"
                                    "border-radius:5px;"
                                    "color:rgba(255,255,255);"
                                    "}"
                                    );

    ui->pushButton_11->setStyleSheet("QPushButton{"
                                    "background-color:rgb(255,69,0);"
                                    "border-style:outset;"
                                    "border-radius:5px;"
                                    "color:rgba(255,255,255);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "background-color:rgb(255,69,0,200);"
                                    "border-radius:5px;"
                                    "color:rgba(255,255,255);"
                                    "}"
                                    );

    ui->pushButton_7->setStyleSheet("color:rgba(178,34,34);");

    ui->pushButton_8->setStyleSheet( //正常状态样式
                                     "QPushButton{"
                                     "background-color:rgba(250,128,114,50);"//背景色（也可以设置图片）
                                     "color:rgba(178,34,34);"                //字体颜色
                                     "}"
                                     //鼠标按下样式
                                     "QPushButton:pressed{"
                                     "background-color:rgba(250,128,114,50);"
                                     "color:rgba(178,34,34);"
                                     "}"
                                     //鼠标悬停样式
                                     "QPushButton:hover{"
                                     "color:rgba(178,34,34);"
                                     "}");

    ui->pushButton_9->setStyleSheet( //正常状态样式
                                     "QPushButton{"
                                     "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                     "color:rgba(90,90,90);"                //字体颜色
                                     "}"
                                     //鼠标按下样式
                                     "QPushButton:pressed{"
                                     "background-color:rgba(250,128,114,50);"
                                     "color:rgba(178,34,34);"
                                     "}"
                                     //鼠标悬停样式
                                     "QPushButton:hover{"
                                     "color:rgba(178,34,34);"
                                     "}");

    ui->pushButton_10->setStyleSheet( //正常状态样式
                                     "QPushButton{"
                                     "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                     "color:rgba(90,90,90);"                //字体颜色
                                     "}"
                                      //鼠标按下样式
                                      "QPushButton:pressed{"
                                      "background-color:rgba(250,128,114,50);"
                                      "color:rgba(178,34,34);"
                                      "}"
                                      //鼠标悬停样式
                                      "QPushButton:hover{"
                                      "color:rgba(178,34,34);"
                                      "}");

    ui->pushButton_12->setStyleSheet("QPushButton{"
                                     "color:rgba(211,211,211);"
                                     "}"
                                     //鼠标悬停样式
                                     "QPushButton:hover{"
                                     "color:rgba(50,50,50);"
                                     "}");

    ui->pushButton_13->setStyleSheet("QPushButton{"
                                     "background-color:rgb(255,69,0);"
                                     "border-style:outset;"
                                     "border-radius:5px;"
                                     "color:rgba(255,255,255);"
                                     "}"
                                     //鼠标悬停样式
                                     "QPushButton:hover{"
                                     "background-color:rgb(255,69,0,200);"
                                     "border-radius:5px;"
                                     "color:rgba(255,255,255);"
                                     "}");

    ui->pushButton_14->setStyleSheet("QPushButton{"
                                    "border-style:outset;"
                                    "border-radius:5px;"
                                    "color:rgba(211,211,211);"
                                    "}"
                                    //鼠标悬停样式
                                    "QPushButton:hover{"
                                    "border-radius:5px;"
                                    "color:rgba(105,105,105);"
                                    "}"
                                    );

    ui->pushButton_15->setStyleSheet("QPushButton{"
                                     "background-color:rgb(255,69,0);"
                                     "border-style:outset;"
                                     "border-radius:5px;"
                                     "color:rgba(255,255,255);"
                                     "}"
                                     //鼠标悬停样式
                                     "QPushButton:hover{"
                                     "background-color:rgb(255,69,0,200);"
                                     "border-radius:5px;"
                                     "color:rgba(255,255,255);"
                                     "}");

    ui->pushButton_16->setStyleSheet( //正常状态样式
                                      "QPushButton{"
                                      "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                      "color:rgba(90,90,90);"                //字体颜色
                                      "}"
                                       //鼠标按下样式
                                       "QPushButton:pressed{"
                                       "background-color:rgba(250,128,114,50);"
                                       "color:rgba(178,34,34);"
                                       "}"
                                       //鼠标悬停样式
                                       "QPushButton:hover{"
                                       "color:rgba(178,34,34);"
                                       "}");

    ui->label_7->setStyleSheet("color:rgba(128,128,128);");
    ui->label_8->setStyleSheet("color:rgba(128,128,128);");
    ui->label_9->setStyleSheet("color:rgba(60,60,60);");
    ui->label_10->setStyleSheet("color:rgba(60,60,60);");
    ui->label_12->setStyleSheet("color:rgba(30,30,30);");
    ui->label_13->setStyleSheet("color:rgba(30,30,30);");
    ui->label_11->setStyleSheet("color:rgba(50,50,50);");
    ui->label_15->setStyleSheet("color:rgba(50,50,50);");
    ui->label_14->setStyleSheet("color:rgba(50,50,50);");
    ui->label_14->setWordWrap(true);
    ui->label_14->setAlignment(Qt::AlignTop);


    ui->radioButton->setStyleSheet("color:rgba(128,128,128);");
    ui->radioButton_2->setStyleSheet("color:rgba(128,128,128);");
    ui->radioButton_3->setStyleSheet("color:rgba(128,128,128);");
    ui->radioButton_5->setStyleSheet("color:rgba(128,128,128);");

    ui->listWidget->setViewMode(QListView::ListMode);   //设置显示模式为列表模式
    ui->listWidget->setStyleSheet("background-color:rgb(235,235,235)");
    ui->listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);//隐藏竖向滚动条


    //登录 按钮
    connect(ui->pushButton_5,&QPushButton::clicked,this,[=](){

        form = new Form(this);
        form->setWindowFlags(Qt::SplashScreen);
//        form->setAutoFillBackground(true);
        form->show();

        form->setStyleSheet("background-color:rgb(235,235,235)");
        form->ui->pushButton->setStyleSheet("QPushButton{"
                                            "background-color:rgb(255,69,0);"
                                            "border-style:outset;"
                                            "border-radius:5px;"
                                            "color:rgba(255,255,255);"
                                            "}"
                                            //鼠标悬停样式
                                            "QPushButton:hover{"
                                            "background-color:rgb(255,69,0,200);"
                                            "border-radius:5px;"
                                            "color:rgba(255,255,255);"
                                            "}");

        form->ui->pushButton_2->setStyleSheet("QPushButton{"
                                        "color:rgba(211,211,211);"
                                        "}"
                                        //鼠标悬停样式
                                        "QPushButton:hover{"
                                        "color:rgba(0,0,0);"
                                        "}"
                                        );

        //删除
        connect(ui->pushButton_13,&QPushButton::clicked,this,[=](){

            for(int i=ui->listWidget->currentRow();i<dictionary_list->size();i++){
                dictionary_list[i]=dictionary_list[i+1];
            }

            QFile file("C:\\XR.txt");

            if (file.open(QIODevice::WriteOnly)){

               for(int i=0;i<dictionary_list->size();i++){
                   QTextStream stream(&file);
                   stream.seek(file.size());
                   stream << dictionary_list[i];
               }
                file.close();
            }

            //更新
            int n=ui->listWidget->count();//获取item的总数
            //删去所有item
            for(int i=0;i<n;i++)
            {
                /*
                     使用takeItem(row)函数将QListWidget中的第row个item移除，
                     移除需要使用delete手动释放其在堆上占用的空间
                    */
                QListWidgetItem *item = ui->listWidget->takeItem(0); //这里是0，不是i，因为每移除一个item都会导致每个item的row发生变化
                delete item;
            }

            QFile file1("C:\\XR.txt");
            if (file1.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextCodec *codec = QTextCodec::codecForName("GBK");
                int i=0;
                while (!file1.atEnd())
                {
                    dictionary_list[i] = codec->toUnicode(file1.readLine());

                    QListWidgetItem *add_item = new QListWidgetItem(ui->listWidget);
                    add_item->setText(dictionary_list[i]);
                    add_item->setSizeHint(QSize(650,30));
                    ui->listWidget->insertItem(i,add_item);
                    i++;
                }
                ui->label_5->setText("共"+QString::number(i)+"个词");
                file1.close();
            }


        });

        //排序
        connect(ui->pushButton_15,&QPushButton::clicked,this,[=](){
            QMessageBox::critical(this,"提示","该功能暂未开发，尽情期待！");
        });



        //登录
        connect(form->ui->pushButton_2,&QPushButton::clicked,this,[=](){
            form->close();
        });
        connect(form->ui->pushButton,&QPushButton::clicked,this,[=](){
            if(form->ui->lineEdit->text()=="XR"&&form->ui->lineEdit_2->text()=="418418XR"){
                form->close();
                tag1=1;
                //读取文件
                QFile file("C:\\XR.txt");
                if (file.open(QIODevice::ReadOnly | QIODevice::Text))
                {
                     QTextCodec *codec = QTextCodec::codecForName("GBK");
                    int i=0;
                    while (!file.atEnd())
                    {
                        dictionary_list[i] = codec->toUnicode(file.readLine());

                        QListWidgetItem *add_item = new QListWidgetItem(ui->listWidget);
                        add_item->setText(dictionary_list[i]);
                        add_item->setSizeHint(QSize(650,30));
                        ui->listWidget->insertItem(i,add_item);
                        i++;
                    }
                    ui->label_5->setText("共"+QString::number(i)+"个词");
                    file.close();
                }


            }
            else{
                QMessageBox::critical(this,"错误","密码错误，请重新输入！");
                form->ui->lineEdit->clear();
                form->ui->lineEdit_2->clear();
            }
        });


    });

    connect(ui->pushButton_16,&QPushButton::clicked,this,[=](){
        QMessageBox::critical(this,"提示","该功能暂未开发，尽情期待！");
    });

    //词典 按钮
    connect(ui->pushButton_8,&QPushButton::clicked,this,[=](){
        ui->pushButton_8->setStyleSheet("background-color:rgba(250,128,114,50);"
                                        "color:rgba(178,34,34);");
        ui->pushButton_9->setStyleSheet( //正常状态样式
                                         "QPushButton{"
                                         "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                         "color:rgba(90,90,90);"                //字体颜色
                                         "}"
                                         //鼠标按下样式
                                         "QPushButton:pressed{"
                                         "background-color:rgba(250,128,114,50);"
                                         "color:rgba(178,34,34);"
                                         "}"
                                         //鼠标悬停样式
                                         "QPushButton:hover{"
                                         "color:rgba(178,34,34);"
                                         "}");

        ui->pushButton_10->setStyleSheet( //正常状态样式
                                         "QPushButton{"
                                         "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                         "color:rgba(90,90,90);"                //字体颜色
                                         "}"
                                         //鼠标按下样式
                                         "QPushButton:pressed{"
                                         "background-color:rgba(250,128,114,50);"
                                         "color:rgba(178,34,34);"
                                         "}"
                                         //鼠标悬停样式
                                         "QPushButton:hover{"
                                         "color:rgba(178,34,34);"
                                         "}");
        ui->stackedWidget->setCurrentIndex(0);

    });

    //翻译 按钮
    connect(ui->pushButton_9,&QPushButton::clicked,this,[=](){
        ui->pushButton_9->setStyleSheet("background-color:rgba(250,128,114,50);"
                                        "color:rgba(178,34,34);");
        ui->pushButton_8->setStyleSheet( //正常状态样式
                                         "QPushButton{"
                                         "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                         "color:rgba(90,90,90);"                //字体颜色
                                         "}"
                                         //鼠标按下样式
                                         "QPushButton:pressed{"
                                         "background-color:rgba(250,128,114,50);"
                                         "color:rgba(178,34,34);"
                                         "}"
                                         //鼠标悬停样式
                                         "QPushButton:hover{"
                                         "color:rgba(178,34,34);"
                                         "}");
        ui->pushButton_10->setStyleSheet( //正常状态样式
                                         "QPushButton{"
                                         "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                         "color:rgba(90,90,90);"                //字体颜色
                                         "}"
                                         //鼠标按下样式
                                         "QPushButton:pressed{"
                                         "background-color:rgba(250,128,114,50);"
                                         "color:rgba(178,34,34);"
                                         "}"
                                         //鼠标悬停样式
                                         "QPushButton:hover{"
                                         "color:rgba(178,34,34);"
                                         "}");

        ui->stackedWidget->setCurrentIndex(1);

    });

    //单词本 按钮
    connect(ui->pushButton_10,&QPushButton::clicked,this,[=](){
        ui->pushButton_10->setStyleSheet("background-color:rgba(250,128,114,50);"
                                        "color:rgba(178,34,34);");
        ui->pushButton_8->setStyleSheet( //正常状态样式
                                         "QPushButton{"
                                         "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                         "color:rgba(90,90,90);"                //字体颜色
                                         "}"
                                         //鼠标按下样式
                                         "QPushButton:pressed{"
                                         "background-color:rgba(250,128,114,50);"
                                         "color:rgba(178,34,34);"
                                         "}"
                                         //鼠标悬停样式
                                         "QPushButton:hover{"
                                         "color:rgba(178,34,34);"
                                         "}");

        ui->pushButton_9->setStyleSheet( //正常状态样式
                                         "QPushButton{"
                                         "background-color:rgba(235,235,235);"//背景色（也可以设置图片）
                                         "color:rgba(90,90,90);"                //字体颜色
                                         "}"
                                         //鼠标按下样式
                                         "QPushButton:pressed{"
                                         "background-color:rgba(250,128,114,50);"
                                         "color:rgba(178,34,34);"
                                         "}"
                                         //鼠标悬停样式
                                         "QPushButton:hover{"
                                         "color:rgba(178,34,34);"
                                         "}");
        ui->stackedWidget->setCurrentIndex(2);
    });

    connect(m_Manager,&QNetworkAccessManager::finished,this,&MainWindow::replyFinished);


    //词典 查找
    connect(ui->pushButton_6,&QPushButton::clicked,this,[=](){
        //查找函数
        QStringList ss;
        search(node,ui->lineEdit->text(),ss);

        ss.back().replace(QRegExp("[\\s]+"), " ");
        QStringList strList = ss.back().split(" ");

        ui->label_9->setText(strList[0]);
        QString chinese;
        for(int i=1;i<strList.size();i++){
            chinese+=strList[i]+" ";
        }
        ui->label_10->setText(chinese);
        ui->label_10->setWordWrap(true);
        ui->label_10->setAlignment(Qt::AlignTop);

        if(tag1){int i=0;
            while(i<dictionary_list->size()){
                dictionary_list[i].replace(QRegExp("[\\s]+"), " ");
                if(ui->label_9->text()==dictionary_list[i].split(" ")[0]){
                    ui->pushButton_14->setText("★");
                    ui->pushButton_14->setToolTip("已加入单词本");
                    break;
                }
                else{
                    ui->pushButton_14->setText("☆");
                    ui->pushButton_14->setToolTip("加入单词本");
                }
                i++;
            }
        }
    });

    //添加单词至单词本
    connect(ui->pushButton_14,&QPushButton::clicked,this,[=](){
        qDebug()<<"str";
        if(tag1){
            if(ui->label_9->text()!=NULL&&ui->label_10->text()!=NULL){
                QFile file("C:\\XR.txt");
                if (file.open(QIODevice::ReadWrite |QIODevice::Append)){
                    QTextStream stream(&file);
                    stream << ui->label_9->text()+'\t'+ui->label_10->text()<<"\n";
                    file.close();
                }

                int n=ui->listWidget->count();//获取item的总数
                //删去所有item
                for(int i=0;i<n;i++)
                {
                    /*
                     使用takeItem(row)函数将QListWidget中的第row个item移除，
                     移除需要使用delete手动释放其在堆上占用的空间
                    */
                    QListWidgetItem *item = ui->listWidget->takeItem(0); //这里是0，不是i，因为每移除一个item都会导致每个item的row发生变化
                    delete item;
                }

                if (file.open(QIODevice::ReadOnly | QIODevice::Text))
                {
                    QTextCodec *codec = QTextCodec::codecForName("GBK");
                    int i=0;
                    while (!file.atEnd())
                    {
                        dictionary_list[i] = codec->toUnicode(file.readLine());

                        QListWidgetItem *add_item = new QListWidgetItem(ui->listWidget);
                        add_item->setText(dictionary_list[i]);
                        add_item->setSizeHint(QSize(650,30));
                        ui->listWidget->insertItem(i,add_item);
                        i++;
                    }
                    ui->label_5->setText("共"+QString::number(i)+"个词");
                    file.close();
                }
                ui->pushButton_14->setText("★");
                ui->pushButton_14->setToolTip("已加入单词本");
            }
        }
        else{
            QMessageBox::critical(this,"错误","请登陆后使用！");
        }

    });

    //翻译 查找
    connect(ui->pushButton_11,&QPushButton::clicked,this,[=](){
        //查找函数
        function_data();
    });

    //翻译切换
    connect(ui->pushButton_12,&QPushButton::clicked,this,[=](){
       if(tag){
           from ="en";
           to = "zh";

           ui->label_8->setText("中文");
           ui->label_7->setText("英文");

           tag = 0;
       }
       else{
           from = "zh";
           to ="en";

           ui->label_7->setText("中文");
           ui->label_8->setText("英文");

           tag = 1;
       }
    });

    m_Manager=new QNetworkAccessManager(this);
    if(m_Manager){
        connect(m_Manager,&QNetworkAccessManager::finished,this,&MainWindow::replyFinished);
    }

    //阴影边框效果类
    QGraphicsDropShadowEffect *shadow  = new QGraphicsDropShadowEffect();
    //设置圆角
    shadow->setBlurRadius(20);
    shadow->setColor(Qt::black);

    shadow->setOffset(0);

    ui->frame->setGraphicsEffect(shadow);
    this->setAttribute(Qt::WA_TranslucentBackground);

    setWindowFlags(Qt::FramelessWindowHint);




    trayIcon = new QSystemTrayIcon(this);

    //设置tooltip

    ui->pushButton->setToolTip("关闭");
    ui->pushButton_2->setToolTip("最大化");
    ui->pushButton_3->setToolTip("最小化");
    ui->pushButton_4->setToolTip("mini");
    ui->pushButton_5->setToolTip("登录");
    ui->pushButton_14->setToolTip("加入单词本");
    ui->pushButton_15->setToolTip("排序");

    //关闭窗口
    connect(ui->pushButton,&QPushButton::clicked,this,&QMainWindow::close);

//    connect(ui->pushButton_2,&QPushButton::clicked,this,&QMainWindow::hide);
    connect(ui->pushButton_3,&QPushButton::clicked,this,[=](){
        this->hide();
        trayIcon->show();
        connect(trayIcon,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason)));
    });

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason)
{
    switch(reason){
    case QSystemTrayIcon::Trigger:
        //单击托盘图标
        break;
    case QSystemTrayIcon::DoubleClick:
        //双击托盘图标
        //双击后显示主程序窗口
        this->show();
        break;
    default:
        break;
    }
}


//读取文件
void MainWindow::ReadFile(){
    QFile file(":/new/prefix1/data.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextCodec *codec = QTextCodec::codecForName("GBK");
        int i=0;
        while (!file.atEnd())
        {
            dictionary[i] = codec->toUnicode(file.readLine());
            i++;
        }
        file.close();

    }
}

//下拉框匹配
void MainWindow::MatchCompleter(){
connect(ui->lineEdit,&QLineEdit::textChanged,this,[=](){
    word = ui->lineEdit->text();

    if(ui->radioButton->isChecked()){
        //顺序查找
        shunXu();
    }
    else if(ui->radioButton_2->isChecked()){
        //AVL
        QStringList strlist;

        avlSearch(avlnode,word,strlist);

        //自动匹配下拉框
        QCompleter *completer = new QCompleter(strlist,this);
        //大小写不敏感
        completer->setMaxVisibleItems(strlist.size());
        completer->setCaseSensitivity(Qt::CaseInsensitive);

        QAbstractItemView *popup = completer->popup();

        popup->setFrameShape(QFrame::NoFrame);
        popup->setFrameShadow(QFrame::Plain);

        popup->setStyleSheet("background-color:rgb(240,240,240);"
                             "font-size:14px;"
                             "color:rgba(50,50,50);"
                             "line-height: normal;"
                             "border-width:0;");

        ui->lineEdit->setCompleter(completer);

    }
    else if(ui->radioButton_3->isChecked()){
        //BST
        QStringList strlist;

        search(node,word,strlist);

        //自动匹配下拉框
        QCompleter *completer = new QCompleter(strlist,this);
        //大小写不敏感
        completer->setMaxVisibleItems(strlist.size());
        completer->setCaseSensitivity(Qt::CaseInsensitive);

        QAbstractItemView *popup = completer->popup();

        popup->setFrameShape(QFrame::NoFrame);
        popup->setFrameShadow(QFrame::Plain);

        popup->setStyleSheet("background-color:rgb(240,240,240);"
                             "font-size:14px;"
                             "color:rgba(50,50,50);"
                             "line-height: normal;"
                             "border-width:0;");

        ui->lineEdit->setCompleter(completer);

    }
    else if(ui->radioButton_5->isChecked()){
        //RB
        QMessageBox::critical(this,"提示","该功能暂未开发，尽情期待！");
    }
});
}


//三个鼠标事件的重写，实现窗口移动
void MainWindow::mousePressEvent(QMouseEvent *e)
{
    last = e->globalPos();

    if (e->button() == Qt::LeftButton) {
        //触发clicked信号
        emit clicked();
    }
}
void MainWindow::mouseMoveEvent(QMouseEvent *e)
{
    if(last.x()-this->x()<=900&&last.y()-this->y()<=30){
        int dx = e->globalX() - last.x();
        int dy = e->globalY() - last.y();
        last = e->globalPos();
        move(x()+dx, y()+dy);
    }
}
void MainWindow::mouseReleaseEvent(QMouseEvent *e)
{
    if(last.x()-this->x()<=900&&last.y()-this->y()<=30){
        int dx = e->globalX() - last.x();
        int dy = e->globalY() - last.y();
        move(x()+dx, y()+dy);
    }
}

//处理事件过滤，左击发送信号
bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if(obj==ui->lineEdit){
        if(event->type()==QEvent::MouseButtonPress){
                emit clicked();//左击时发送的信号
        }
    }
    return QWidget::eventFilter(obj, event);
}

void MainWindow::lineEdit_clear(){
    ui->lineEdit->setText("sds");
}

//调用百度翻译api
//发送请求
int MainWindow::function_data()
{
    QString MD5;
    char salt[60];
    sprintf(salt,"%d",rand());  //获取随机数
    text = ui->textEdit->toPlainText();    //获取待翻译的文本
    QString sign=QString("%1%2%3%4")\
        .arg(MY_APID).arg(text).arg(salt).arg("MY_APID_KEY");//连接加密文件 宏MY_APID 是你的开发账号 宏MY_APID_KEY 是你的开发者密匙

    QByteArray str = QCryptographicHash::hash(sign.toUtf8(),QCryptographicHash::Md5);
    MD5.append(str.toHex());//生成md5加密文件
    QString myurl=QString("http://api.fanyi.baidu.com/api/trans/vip/translate?" \
           "q=%1&from=%2&to=%3&appid=%4""&salt=%5&sign=%6")\
           .arg(text).arg(from).arg(to).arg(MY_APID_KEY).arg(salt).arg(MD5);

    m_Manager->get(QNetworkRequest(QUrl(myurl)));//发送上传

    return 1;

}

//解码返回值
int MainWindow::replyFinished(QNetworkReply *reply)
{

    QJsonParseError jsonError;
    QByteArray all=reply->readAll();//获得api返回值
   /* 大概是这样的一个东西
   {"from":"en","to":"zh","trans_result":[{"src":"apple","dst":"\u82f9\u679c"}]}
   你需要解码 */
    QJsonDocument json = QJsonDocument::fromJson(all, &jsonError);
    QJsonObject object = json.object();//json转码；
    QString cResult;
    if(object.contains("error_code"))
    {
        int nResult=object.value("error_code").toInt();

        switch (nResult) {
        case 52001:
            cResult ="52001 请求超时 重试";
            break;
        case 52002:
            cResult ="52002 系统错误 重试";
            break;
        case 54000:
            cResult ="54000 必填参数为空";
            break;
        case 54001:
            cResult ="54001 签名错误";
            break;
        case 54003:
            cResult ="54003 速度过快访问频率受限";
            break;
        case 54004:
            cResult ="54004 账户余额不足";
            break;
        case 54005:
            cResult ="54005 请求频繁";
            break;
        case 58002:
            cResult ="58002 服务关闭";
            break;
        default:
            cResult ="其他错误";
            break;
        }
    }
    else {
        QJsonArray value = object.value("trans_result").toArray();//一次解码

        QJsonObject object1=value.at(0).toObject();//二次解码开【】括号；

        cResult=object1.value("dst").toString();//得到翻译结果
    }

    ui->textEdit_2->setText(cResult);
    reply->deleteLater();
    return 1;

}


//顺序查找
void MainWindow::shunXu(){
    int num = 0;
    int n=0;
    int m=1;
    int match=0;

    QString str;
    QStringList strlist;
    while(num<6){
        int number = 0;
        while(number<word.size()){
            number = 0;
            str = dictionary[n];
            for(int i=0;i<word.size();i++){
                if(word[i]==str[i]){
                    number++;
                }
            }
            if(number<match||(n>103975&&number<word.size())){
                m=0;
                number=word.size();
            }
            n++;
        }

        match=number;

        if(m){
            strlist<<str;
            num++;
        }
        else{
            if(strlist.isEmpty()){
                strlist<<word;
            }
            num=6;
        }
    }

    //自动匹配下拉框
    QCompleter *completer = new QCompleter(strlist,this);
    //大小写不敏感
    completer->setMaxVisibleItems(strlist.size());
    completer->setCaseSensitivity(Qt::CaseInsensitive);

    QAbstractItemView *popup = completer->popup();

    popup->setStyleSheet("background-color:rgb(240,240,240);"
                         "font-size:14px;"
                         "color:rgba(50,50,50);"
                         "line-height: normal;"
                         "border-width:0;");

    ui->lineEdit->setCompleter(completer);


}

//bst
void MainWindow::insert(Node *&root, QString &str)//return false if the key already exists
{
    str.replace(QRegExp("[\\s]+"), " ");
    QStringList strList = str.split(" ");

    QString english=strList[0];
    QString chinese;
    for(int i=1;i<strList.size();i++){
        chinese+=strList[i]+" ";
    }

if(root==NULL)
{
   Node *node1 = new Node;
   node1->english = english;
   node1->chinese = chinese;
   node1->left = node1->right = NULL;
   root = node1;
}
else if(english < root->english)
    insert(root->left,str);
else if(english > root->english)
    insert(root->right,str);
else{

}
}


void MainWindow::search(Node *root, QString str,QStringList &sl){
    if(root==NULL){
        sl<<str;
        if(sl.size()>6){
            sl.pop_front();
        }
    }

    else if(str < root->english){
        sl<<root->english+'\t'+root->chinese;
        if(sl.size()>6){
            sl.pop_front();
        }
        search(root->left,str,sl);
    }
    else if(str > root->english){
        sl<<root->english+'\t'+root->chinese;
        if(sl.size()>6){
            sl.pop_front();
        }
        search(root->right,str,sl);
    }
    else{
        sl<<root->english+'\t'+root->chinese;
        if(sl.size()>6){
            sl.pop_front();
        }
    }

}

bool MainWindow::avlInsert(AVLNode*& root, QString &str){
    str.replace(QRegExp("[\\s]+"), " ");
    QStringList strList = str.split(" ");

    QString english=strList[0];
    QString chinese;
    for(int i=1;i<strList.size();i++){
        chinese+=strList[i]+" ";
    }

    int d;
    stack<AVLNode *> s;
    AVLNode *pr = NULL , *p = root,*q;

    while(p != NULL){
        if(english == p->english) return false;
        pr = p;
        s.push(pr);
        if(english > p->english){
           p=p->right;
       }
        else if(english<p->english){
            p=p->left;
        }
    }

    p = new AVLNode;
    p->left=p->right=NULL;
    p->english=english;
    p->chinese=chinese;
    p->bf=0;

    if(pr==NULL) {root=p;return true;}
    if(english > pr->english){
       pr->right=p;
   }
    else if(english<pr->english){
        pr->left=p;
    }

    while (s.empty() == false){      //重新平衡化
        pr=s.top();
        s.pop();
        //从栈中退出父结点
        if (p== pr->left) pr->bf--;       //调整父结点的平衡因子
        else pr->bf++;
        if (pr->bf==0) {break;}          //第1种情况,平衡退出
        if (pr->bf == 1||pr->bf == -1)  //第2种情况,|bf|-1
        {p = pr;}
        else {                        //第3种情况,|bf|-2
            d= (pr->bf<0)?-1:1;            //区别单双旋转标志
            if(p->bf== d){             //两结点平衡因子同号,单旋转
                if(d==-1)RotateR(pr);         //右单旋转
                else RotateL(pr);             //左单旋转
            }
            else {                       //两结点平衡因子反号,双旋转
                if(d==-1) RotateLR(pr);      //先左后右双旋转,“<”型
                else RotateRL(pr);           //先右后左双旋转,“>”型
            }
            break;
        }
    }
    if (s.empty()==true) root = pr;
    else {                       //中间重新链接
        q=s.top();
        if (q->english> pr->english)q->left = pr;
        else q->right= pr;
    }
    return true;
}

void MainWindow::RotateR(AVLNode *&root){
    AVLNode *subR = root;
    root = subR->left;
    subR->left = root->right;
    root->right = subR;
    root->bf = subR->bf=0;
}

void MainWindow::RotateL(AVLNode *&root){
    AVLNode *subL = root;
    root = subL->right;
    subL->right = root->left;
    root->left = subL;
    root->bf = subL->bf=0;
}
void MainWindow::RotateLR(AVLNode *&root){
    AVLNode *subR = root, *subL =subR->left;
    root = subL->right;
    subL->right =root->left;
    root->left =subL;
    if(root->bf<=0) subL->bf=0;
    else subL->bf = -1;
    subR->left =root->right;
    root->right =subR;
    if(root->bf ==-1)subR->bf=1;
    else subR->bf=0;
    root->bf=0;
}
void MainWindow::RotateRL(AVLNode *&root){
    AVLNode *subL = root, *subR =subL->right;
    root = subR->left;
    subR->left =root->right;
    root->right =subR;
    if(root->bf>=0) subR->bf=0;
    else subR->bf = 1;
    subL->right =root->left;
    root->left =subL;
    if(root->bf ==1)subL->bf=-1;
    else subL->bf=0;
    root->bf=0;
}

void MainWindow::avlSearch(AVLNode *root, QString str,QStringList &sl){
    if(root==NULL){
        sl<<str;
        if(sl.size()>6){
            sl.pop_front();
        }
    }

    else if(str < root->english){
        sl<<root->english+'\t'+root->chinese;
        if(sl.size()>6){
            sl.pop_front();
        }
        avlSearch(root->left,str,sl);
    }
    else if(str > root->english){
        sl<<root->english+'\t'+root->chinese;
        if(sl.size()>6){
            sl.pop_front();
        }
        avlSearch(root->right,str,sl);
    }
    else{
        sl<<root->english+'\t'+root->chinese;
        if(sl.size()>6){
            sl.pop_front();
        }
    }
}
