#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);

    ui->lineEdit->setPlaceholderText("请输入您的用户名");
    ui->lineEdit_2->setPlaceholderText("请输入密码");


}

Form::~Form()
{
    delete ui;
}
